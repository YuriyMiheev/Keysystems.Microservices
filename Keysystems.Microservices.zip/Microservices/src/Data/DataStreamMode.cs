﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microservices.Data
{
	/// <summary>
	/// 
	/// </summary>
	public enum DataStreamMode
	{
		/// <summary>
		/// 
		/// </summary>
		READ,

		/// <summary>
		/// 
		/// </summary>
		WRITE
	}
}
