﻿using Microservices.Data;

namespace Microservices.Bus.Data
{
	public interface IBusDatabase : IDatabase
	{
	}
}
