﻿
using Microsoft.Extensions.Hosting;

namespace Microservices.Bus
{
	/// <summary>
	/// Сервис сообщений.
	/// </summary>
	public interface IMessageService : IHostedService
	{

		#region Properties
		#endregion


		///// <summary>
		///// 
		///// </summary>
		//ServiceInfo GetInfo();

		///// <summary>
		///// 
		///// </summary>
		///// <param name="updateParams"></param>
		//void UpdateInfo(ServiceInfoUpdateParams updateParams);

		///// <summary>
		///// 
		///// </summary>
		///// <param name="reinitService"></param>
		//void SaveInfo(bool reinitService);

	}
}
