﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microservices.Bus.src.Addins
{
	interface IMicroserviceDescription
	{
	}
}
