﻿namespace Microservices.Bus.Addins
{
	public class AddinManagerOptions
	{
		public string AddinsDirectory { get; set; }

		public string ConfigFileName { get; set; }
	}
}
