﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microservices.Bus
{
	public static class MessageExtensions
	{
	}
}
