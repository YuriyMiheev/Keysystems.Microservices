﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Microservices.Channels.Logging
{
	public class ChannelLogger : ILogger
	{
		public void InitializeLogger()
		{
		}

		public void LogError(Exception error)
		{
		}

		public void LogError(string text, Exception error)
		{
		}

		public void LogInfo(string text)
		{
		}

		public void LogTrace(string text)
		{
		}
	}
}
